def main():
    print("Hello from openai-reg!")


if __name__ == "__main__":
    main()
