# 工具类

* 辩手 - [debater.txt](debater.txt) by [@zhexiuamoy](https://github.com/zhexiuamoy)
* 律师 - [lawyer.txt](lawyer.txt) by [@zhexiuamoy](https://github.com/zhexiuamoy)
* 答疑助手 - [Lss233.txt](Lss233.txt) by [@zhexiuamoy](https://github.com/zhexiuamoy)
* 室内设计师 - [shineisheji.txt](shineisheji.txt) by [@zhexiuamoy](https://github.com/zhexiuamoy)
* 小说家 - [novelist.txt](novelist.txt) by [@zhexiuamoy](https://github.com/zhexiuamoy)
* 诗人 - [poet.txt](poet.txt) by [@zhexiuamoy](https://github.com/zhexiuamoy)
* 必应 - [bing.txt](bing.txt) by [@zhexiuamoy](https://github.com/zhexiuamoy)
* 跑团KP - [kp.txt](kp.txt) by [@benny502](https://github.com/benny502)
* 长回复 - [long.txt](long.txt) by [@zhmou](https://github.com/zhmou)
