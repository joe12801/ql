# OpenAI Auto-Registrar

自动注册 OpenAI 账号并获取 Codex CLI Token。

## 使用方法

```bash
# 安装依赖
uv sync

# 单次注册
uv run python openai_reg.py --proxy http://127.0.0.1:7890 --once

# 批量注册（Ctrl+C 停止）
uv run python openai_reg.py --proxy http://127.0.0.1:7890

# 自定义间隔
uv run python openai_reg.py --proxy http://127.0.0.1:7890 --sleep-min 10 --sleep-max 60

# 3 线程并发注册
uv run python openai_reg.py --proxy http://127.0.0.1:7890 --workers 3

# 使用 DuckMail 自有域名（不易被封）
uv run python openai_reg.py --proxy http://127.0.0.1:7890 --duckmail-key dk_xxx --once

# 注册成功后自动推送到本地 Sub2Api（默认开启）
uv run python openai_reg.py --proxy http://127.0.0.1:7890 --once

# 禁用 Sub2Api 推送
uv run python openai_reg.py --proxy http://127.0.0.1:7890 --no-sub2api --once

# 并发注册 + 并行推送 Sub2Api
uv run python openai_reg.py --proxy http://127.0.0.1:7890 --workers 3
```

### 参数说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--proxy` | 无 | HTTP 代理地址（不支持 CN/HK IP） |
| `--once` | 否 | 只运行一次 |
| `--workers N` | 1 | 并发线程数 |
| `--sleep-min` | 5 | 循环模式最短等待秒数 |
| `--sleep-max` | 30 | 循环模式最长等待秒数 |
| `--duckmail-key` | 无 | DuckMail API Key（dk_xxx），使用自有域名 |
| `--no-sub2api` | 否 | 禁用推送到 Sub2Api（默认自动推送到 127.0.0.1:8080） |

> **并行推送说明**：`--workers` 下每个线程独立注册和推送，推送本身已线程安全，无需额外配置。

成功后 Token 保存为 `token_邮箱_时间戳.json`。

## 注册流程

脚本模拟浏览器完成 OpenAI 的完整注册流程，支持两条路径：

### 路径 A：直接注册（无手机验证）

部分地区节点（如 ID、KR、SG）不要求手机号，流程如下：

```
1. 提交邮箱       POST /api/accounts/authorize/continue
                   Body: {"username": {"value": email, "kind": "email"}, "screen_hint": "signup"}

2. 设置密码       POST /api/accounts/user/register
                   Body: {"password": pwd, "username": email}
                   Sentinel flow: username_password_create

3. 邮箱 OTP 验证  GET  /api/accounts/email-otp/send  (触发发送)
                   POST /api/accounts/email-otp/validate  (提交验证码)

4. 创建账户       POST /api/accounts/create_account
                   Body: {"name": "...", "birthdate": "YYYY-MM-DD"}

5. 选择 workspace POST /api/accounts/workspace/select

6. 获取 Token     跟踪重定向链，捕获 OAuth callback，交换 Token
```

### 路径 B：跳过手机验证，密码登录获取 Token

部分地区节点（如 JP、US、DE、AU）注册后要求手机号验证（`add_phone`），脚本会自动跳过手机验证步骤，改用密码登录获取 Token：

```
1-4. 同路径 A（注册完成，账号已创建）

5. 检测到 add_phone → 跳过，发起新的登录 session

6. 提交邮箱(登录)  POST /api/accounts/authorize/continue
                    Body: {"username": {"value": email, "kind": "email"}, "screen_hint": "login"}

7. 提交密码       POST /api/accounts/password/verify
                    Body: {"password": pwd}
                    Sentinel flow: login_password

8. 登录邮箱 OTP   POST /api/accounts/email-otp/validate  (复用临时邮箱)

9. 选择 workspace POST /api/accounts/workspace/select

10. 获取 Token    跟踪重定向链，捕获 OAuth callback，交换 Token
```

> 两条路径均已测试通过，脚本会自动判断走哪条路径，无需手动干预。

## 故障排查指南

### 错误: `Unknown parameter: 'password'` 或 `Unknown parameter: 'xxx'`

**原因**: OpenAI 修改了 API 端点或参数格式。

**排查思路**:

1. **查看注册响应的 `page_type`** — 每步返回的 `page.type` 和 `continue_url` 指示了下一步该做什么
2. **分析前端 JS 源码找到正确的 API 调用** — 这是最可靠的方法：
   - 访问密码页拿到 HTML，从中找到 JS bundle URL
   - 从 `manifest-*.js` 找到对应路由模块的 URL（如 `CREATE_ACCOUNT_PASSWORD` 路由）
   - 下载路由模块 JS，找到 `clientAction` 函数 — 这就是表单提交处理器
   - 从中提取：端点路径、请求体格式、Sentinel flow 名称
   - 再下载 `redirectToPage-*.js` 确认 `l()` 函数如何构造最终请求

**2025-03 的修复案例**:

OpenAI 将密码注册从 `/authorize/continue` 拆分到了独立端点 `/user/register`：

```
旧 (已失效):
  POST /api/accounts/authorize/continue
  Body: {"password": {"value": pwd, "kind": "password"}}
  Sentinel: authorize_continue

新 (当前生效):
  POST /api/accounts/user/register
  Body: {"password": pwd, "username": email}
  Sentinel: username_password_create
```

关键发现方法：下载路由模块 JS (`route-*.js`) 后看到：
```js
// CREATE_ACCOUNT_PASSWORD 路由的 clientAction:
const i = await oe(ie("username_password_create"), 5e3);  // sentinel flow
return l(r, "/user/register", {                            // 端点
  body: JSON.stringify({password: ..., username: ...})      // body 格式
});
```

### 错误: `registration_disallowed` 或 `unsupported_email`

**原因**: 临时邮箱域名被 OpenAI 拉黑。

**排查步骤**:

1. 确认前面所有步骤（提交邮箱、设密码、OTP 验证）都返回 200
2. 如果只有最后 `create_account` 返回 400 + `registration_disallowed`/`unsupported_email`，则是邮箱域名问题
3. 更换邮箱服务商，选择域名看起来像正常域名的服务

**已知被封域名** (截至 2026-03):
- `sharebot.net` (Mail.tm)  → `registration_disallowed`
- `oakon.com` (mail.gw)     → `unsupported_email`
- `raleigh-construction.com` (mail.gw) → `unsupported_email`

**当前可用**: `tempmail.lol` — 域名如 `leadharbor.org`、`sixthirtydance.org` 等，未被封禁。

**如果 tempmail.lol 也被封了**: 需要寻找新的临时邮箱 API，要求：
- 有创建邮箱和读取邮件的 API
- 域名不在 OpenAI 的一次性邮箱黑名单上
- 兼容性好的候选：找域名看起来像正常公司/组织的服务

### 错误: `授权 Cookie 里没有 workspace 信息`

**原因**: OpenAI 在注册流程中插入了手机号验证步骤（`add_phone`），在手机验证完成前不会分配 workspace。

**当前处理方式**: 脚本已自动处理。检测到 `add_phone` 后会跳过手机验证，改用密码登录流程（路径 B）获取 Token，无需任何手动操作。

### 错误: OTP 验证码一直收不到

**排查步骤**:

1. 先看注册响应的 `page_type` — 如果是 `create_account_password` 说明下一步是设密码，**不需要 OTP**
2. OTP 是在密码设置成功后才发送的（`/user/register` 返回 `page_type=email_otp_send`）
3. 需要 GET `continue_url`（即 `/api/accounts/email-otp/send`）来触发发送
4. 然后才能从邮箱轮询到验证码

### 错误: 网络超时 / 代理问题

```bash
# 测试代理
curl.exe -x http://127.0.0.1:7890 https://cloudflare.com/cdn-cgi/trace

# 注意：不能用中国大陆/香港 IP，脚本会检测 loc=CN/HK 并拒绝
```

## 通用调试方法：分析 OpenAI 前端 JS

当 API 报错且无法猜出正确参数时，最可靠的方法是分析 OpenAI 的前端代码：

```
1. GET 目标页面 HTML（如 /create-account/password）
2. 从 HTML 中找 <link> 标签里的 JS asset URL
3. 找到 manifest-*.js → 搜索目标路由名（如 CREATE_ACCOUNT_PASSWORD）
   → 获取该路由的 module URL（如 route-*.js）
4. 下载 route-*.js → 找 clientAction 函数
   → 提取 sentinel flow、端点路径、body 格式
5. 下载 redirectToPage-*.js → 确认请求构造方式
   → 函数名映射: l() = 发起API请求, q() = 路由分发
```

这个方法在 API 任何参数变化时都适用，因为前端 JS 必须和后端 API 保持一致。

## 架构说明

- **临时邮箱**: 优先 `tempmail.lol`，回退 `mail.gw`（API 兼容 Mail.tm）
- **反检测**: 使用 `curl_cffi` 模拟 Chrome TLS 指纹
- **Sentinel Token**: OpenAI 的反自动化机制，每步操作前需获取
- **OAuth PKCE**: 最终通过 PKCE 流程换取 access_token + refresh_token
- **手机验证绕过**: 检测到 `add_phone` 时自动切换到密码登录流程，复用临时邮箱完成登录 OTP 验证
- **Clash 节点轮换**: 可选功能，每次注册前通过 Clash RESTful API 随机切换代理节点

### Clash 节点轮换配置

在 `openai_reg.py` 顶部配置：

```python
CLASH_ENABLED = True                    # True 启用 / False 关闭
CLASH_API_URL = "http://127.0.0.1:9097" # Clash API 地址
CLASH_SECRET = "set-your-secret"        # Clash API 密钥
CLASH_PROXY_GROUP = "你的代理组名称"      # 代理组名称
```

关闭后使用 `--proxy` 指定的固定代理节点。
